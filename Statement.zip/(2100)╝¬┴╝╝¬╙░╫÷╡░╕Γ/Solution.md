# 题解

将每个蛋糕转化为二维平面上的坐标（限定在第一象限）

以$x$表示$a$，$y$表示$b$，那么根据题意，点$(x,y)$在一步之内可以转移到与其相邻及与其呈对角线关系的总共八个点（如果合法）

那么我们可以二分$minOp(cake_i,demo)$，对于每个订单，其代表的区域在二维平面上为一个矩形

二分的检查方案就是检查$n$个矩形是否存在公共点。若存在公共点，任意公共点都能作为答案。

总时间复杂度$O(nlogm)$

```c++
#include<bits/stdc++.h>
using namespace std;

int n,a[500050],b[500050];

struct node
{
    int left,right,bottom,top;
};

node check(int op)
{
    node nd=node{0,2000000,0,2000000};
    
    for(int i=1;i<=n;i++)
    {
        nd.left=max(nd.left,a[i]-op);
        nd.right=min(nd.right,a[i]+op);
        nd.bottom=max(nd.bottom,b[i]-op);
        nd.top=min(nd.top,b[i]+op);
    }
    
    if(nd.left>nd.right||nd.bottom>nd.top)
        nd.left=-1;
    return nd;
}

int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d%d",&a[i],&b[i]);
    if(n==1)
        printf("0\n%d %d\n",a[1],b[1]);
    else
    {
        int l=0,r=2000000;
        while(l<=r)
        {
            int mid=(l+r)>>1;
            if(check(mid).left==-1)
                l=mid+1;
            else
                r=mid-1;
        }
        printf("%d\n",l);
        node nd=check(l);
        printf("%d %d\n",nd.left,nd.bottom);
    }
    
    return 0;
}
```

