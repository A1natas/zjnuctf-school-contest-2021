#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;

const int INF=0x3f3f3f3f;

int main(int argc, char* argv[])
{
    registerTestlibCmd(argc, argv);
    // initializes checker environment
    
    // inf - stream with the testdata.
    // ouf - stream with the contestant output.
    // ans - stream with the jury answer.
    // All those streams provide the similar interface for reading data.
    
    int d=ouf.readInt();
    int ansd=ans.readInt();
    
    if(d>ansd)
        quitf(_wa, "SY has a better solution!");
    
    int n1=ouf.readInt(),n2=ouf.readInt();
    
    int n=inf.readInt();
    for(int i=1;i<=n;i++)
    {
        int d1=inf.readInt(),d2=inf.readInt();
        if(max(abs(d1-n1),abs(d2-n2))>d)
            quitf(_wa, "given minimum operation = %d, but actual operation = %d in line %d",ansd,max(abs(d1-n1),abs(d2-n2)),i);
    }
    
    quitf(_ok, "minimum operation = %d",d);
}
